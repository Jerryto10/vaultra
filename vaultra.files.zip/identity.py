# Copyright (c) 2026 Jerly Rojas
# Vaultra — AI Agent Compliance Layer
# https://vaultra.io
#
# Este software está protegido bajo licencia AGPL-3.0.
# Para uso comercial sin publicar modificaciones,
# contacta: legal@vaultra.io
#
# This software is protected under the AGPL-3.0 license.
# For commercial use without publishing modifications,
# contact: legal@vaultra.io
# -------------------------------------------------------
"""
AgentShield - Capa 1: Identity Layer
=====================================
Provee identidad criptográfica a cada agente IA.
Cada agente recibe un par de claves Ed25519 + un "propósito fijo" (scope).
Cualquier instrucción fuera del scope es rechazada criptográficamente.

Autor: AgentShield Project
"""

import json
import time
import uuid
import hashlib
import secrets
from dataclasses import dataclass, field, asdict
from typing import Optional
from enum import Enum

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives import serialization
from cryptography.exceptions import InvalidSignature


# ─────────────────────────────────────────────
# ENUMS Y CONSTANTES
# ─────────────────────────────────────────────

class AgentStatus(str, Enum):
    ACTIVE    = "active"
    REVOKED   = "revoked"
    SUSPENDED = "suspended"


class TrustLevel(int, Enum):
    """Nivel de confianza del agente. Define qué puede firmar/ejecutar."""
    LOW      = 1   # Solo puede leer / consultar
    MEDIUM   = 2   # Puede generar contenido
    HIGH     = 3   # Puede ejecutar acciones reversibles
    CRITICAL = 4   # Puede ejecutar acciones irreversibles (requiere Human Gate)


# ─────────────────────────────────────────────
# DATACLASSES
# ─────────────────────────────────────────────

@dataclass
class AgentScope:
    """
    Define el propósito fijo del agente.
    Todo lo que no esté en 'allowed_actions' es rechazado.
    """
    purpose: str                          # Descripción en lenguaje natural
    allowed_actions: list[str]            # Ej: ["search", "summarize", "reply"]
    forbidden_actions: list[str]          # Ej: ["send_email", "delete_file"]
    max_trust_level: TrustLevel = TrustLevel.MEDIUM
    context_tags: list[str] = field(default_factory=list)  # Ej: ["finance", "readonly"]

    def allows(self, action: str) -> bool:
        if action in self.forbidden_actions:
            return False
        return action in self.allowed_actions

    def to_dict(self) -> dict:
        d = asdict(self)
        d["max_trust_level"] = self.max_trust_level.value
        return d


@dataclass
class AgentIdentity:
    """
    Identidad criptográfica de un agente.
    Contiene su ID, clave pública, scope y metadata.
    """
    agent_id: str
    public_key_bytes: bytes
    scope: AgentScope
    created_at: float
    status: AgentStatus = AgentStatus.ACTIVE
    revoked_at: Optional[float] = None
    revocation_reason: Optional[str] = None

    def is_active(self) -> bool:
        return self.status == AgentStatus.ACTIVE

    def fingerprint(self) -> str:
        """Hash corto para identificación rápida."""
        return hashlib.sha256(self.public_key_bytes).hexdigest()[:16]

    def to_dict(self) -> dict:
        return {
            "agent_id": self.agent_id,
            "public_key": self.public_key_bytes.hex(),
            "fingerprint": self.fingerprint(),
            "scope": self.scope.to_dict(),
            "created_at": self.created_at,
            "status": self.status.value,
            "revoked_at": self.revoked_at,
            "revocation_reason": self.revocation_reason,
        }


@dataclass
class SignedMessage:
    """
    Mensaje firmado criptográficamente por un agente.
    Incluye el contenido, la firma, el agent_id y un timestamp.
    """
    agent_id: str
    payload: dict
    signature: bytes
    timestamp: float
    nonce: str  # Previene replay attacks

    def to_dict(self) -> dict:
        return {
            "agent_id": self.agent_id,
            "payload": self.payload,
            "signature": self.signature.hex(),
            "timestamp": self.timestamp,
            "nonce": self.nonce,
        }


# ─────────────────────────────────────────────
# AGENTE CORE
# ─────────────────────────────────────────────

class Agent:
    """
    Agente IA con identidad criptográfica.
    Genera su propio par de claves Ed25519 al crearse.
    """

    def __init__(self, name: str, scope: AgentScope):
        self._private_key: Ed25519PrivateKey = Ed25519PrivateKey.generate()
        self._public_key: Ed25519PublicKey = self._private_key.public_key()
        self._used_nonces: set[str] = set()

        public_bytes = self._public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

        self.name = name
        self.identity = AgentIdentity(
            agent_id=str(uuid.uuid4()),
            public_key_bytes=public_bytes,
            scope=scope,
            created_at=time.time(),
        )

    @property
    def agent_id(self) -> str:
        return self.identity.agent_id

    def sign_message(self, action: str, content: dict) -> SignedMessage:
        """
        Firma un mensaje. Falla si la acción no está en el scope del agente.
        """
        if not self.identity.is_active():
            raise PermissionError(
                f"[AgentShield] Agente '{self.name}' está {self.identity.status.value}. "
                "No puede firmar mensajes."
            )

        if not self.identity.scope.allows(action):
            raise PermissionError(
                f"[AgentShield] Acción '{action}' fuera del scope del agente '{self.name}'.
"
                f"  Permitidas: {self.identity.scope.allowed_actions}
"
                f"  Prohibidas: {self.identity.scope.forbidden_actions}"
            )

        nonce = secrets.token_hex(16)
        timestamp = time.time()

        payload = {
            "agent_id": self.agent_id,
            "action": action,
            "content": content,
            "timestamp": timestamp,
            "nonce": nonce,
        }

        payload_bytes = json.dumps(payload, sort_keys=True).encode()
        signature = self._private_key.sign(payload_bytes)

        return SignedMessage(
            agent_id=self.agent_id,
            payload=payload,
            signature=signature,
            timestamp=timestamp,
            nonce=nonce,
        )

    def export_public_identity(self) -> AgentIdentity:
        """Exporta la identidad pública (sin clave privada) para el Registry."""
        return self.identity


# ─────────────────────────────────────────────
# REGISTRY (Directorio de agentes conocidos)
# ─────────────────────────────────────────────

class AgentRegistry:
    """
    Registro central de identidades de agentes.
    Verifica firmas y gestiona revocaciones.
    """

    def __init__(self):
        self._agents: dict[str, AgentIdentity] = {}
        self._revocation_log: list[dict] = []

    def register(self, identity: AgentIdentity) -> None:
        """Registra un agente en el directorio."""
        if identity.agent_id in self._agents:
            raise ValueError(f"Agente '{identity.agent_id}' ya está registrado.")
        self._agents[identity.agent_id] = identity
        print(f"[Registry] ✅ Agente registrado: {identity.agent_id[:8]}... "
              f"| Fingerprint: {identity.fingerprint()}")

    def revoke(self, agent_id: str, reason: str) -> None:
        """Revoca un agente. Sus mensajes futuros serán rechazados."""
        if agent_id not in self._agents:
            raise KeyError(f"Agente '{agent_id}' no encontrado.")

        identity = self._agents[agent_id]
        identity.status = AgentStatus.REVOKED
        identity.revoked_at = time.time()
        identity.revocation_reason = reason

        self._revocation_log.append({
            "agent_id": agent_id,
            "revoked_at": identity.revoked_at,
            "reason": reason,
        })
        print(f"[Registry] 🚫 Agente revocado: {agent_id[:8]}... | Razón: {reason}")

    def verify(self, message: SignedMessage) -> bool:
        """
        Verifica la autenticidad e integridad de un mensaje firmado.
        Retorna True si es válido, False si no.
        """
        identity = self._agents.get(message.agent_id)

        if identity is None:
            print(f"[Registry] ❌ Agente desconocido: {message.agent_id[:8]}...")
            return False

        if not identity.is_active():
            print(f"[Registry] ❌ Agente {message.agent_id[:8]}... está {identity.status.value}")
            return False

        # Anti-replay: verificar nonce único
        nonce_key = f"{message.agent_id}:{message.nonce}"
        if nonce_key in self._used_nonces:
            print(f"[Registry] ❌ Replay attack detectado. Nonce ya usado: {message.nonce}")
            return False

        # Verificar expiración del mensaje (5 minutos máximo)
        age = time.time() - message.timestamp
        if age > 300:
            print(f"[Registry] ❌ Mensaje expirado ({age:.0f}s de antigüedad)")
            return False

        # Verificar firma criptográfica
        try:
            public_key = Ed25519PublicKey.from_public_bytes(identity.public_key_bytes)
            payload_bytes = json.dumps(message.payload, sort_keys=True).encode()
            public_key.verify(message.signature, payload_bytes)
        except InvalidSignature:
            print(f"[Registry] ❌ Firma inválida para agente {message.agent_id[:8]}...")
            return False

        # Todo OK: marcar nonce como usado
        self._used_nonces.add(nonce_key)
        print(f"[Registry] ✅ Mensaje verificado | Agente: {message.agent_id[:8]}... "
              f"| Acción: {message.payload['action']}")
        return True

    def get_identity(self, agent_id: str) -> Optional[AgentIdentity]:
        return self._agents.get(agent_id)

    def list_agents(self) -> list[dict]:
        return [identity.to_dict() for identity in self._agents.values()]

    @property
    def _used_nonces(self):
        if not hasattr(self, "_nonces"):
            self._nonces = set()
        return self._nonces
